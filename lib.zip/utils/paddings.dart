// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:setting_check/utils/phone_size.dart';

final main_padding =
    EdgeInsets.fromLTRB(PhoneSize.width * 0.04, 0, PhoneSize.width * 0.04, 0);
