import 'package:get/get.dart';

class PhoneSize {
  static final double width = Get.width;
  static final double height = Get.height;
}
