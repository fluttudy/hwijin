// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';

const checkBox_textStyle = TextStyle(fontSize: 18.0);
